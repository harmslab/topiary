/Users/harmsm/local/bin/generax --families control.txt --species-tree species_tree.newick --prefix result --rec-model UndatedDTL --seed 12345 &> topiary.log
