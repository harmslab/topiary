generax --families control.txt --species-tree species_tree.newick --prefix result --rec-model UndatedDTL &> topiary.log
